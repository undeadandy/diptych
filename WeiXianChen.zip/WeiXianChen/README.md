# diptych
In class activity: Computation pt 2
1) Download the following: "Diptych_v4_sound.zip"
2) Uncompress 
3) Rename the .pde to include your name
4) Upload as a new branch to the repository
5) Replace default asset files with your own
6) Upload the asset files

ATTENTION: Keep the same file structure as source code files
